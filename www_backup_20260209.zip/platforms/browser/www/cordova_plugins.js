cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-browsersync-gen2": "1.1.7",
    "cordova-plugin-firebasex": "19.0.1"
}
// BOTTOM OF METADATA
});